sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("ztch.ztchdms01v1.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map